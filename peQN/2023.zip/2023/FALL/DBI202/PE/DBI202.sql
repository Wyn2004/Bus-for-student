﻿-- Question 1 (1 mark):
-- For the department with the name: 'Phòng phần mềm nước ngoài', which projects are managed by this department currently?
-- Required information: project number, project name, name of management department
select	p.proNum as N'Project Number',
		p.proName as N'Project Name',
		d.depName as N'Name Of Management Department'
from tblDepartment as d
inner join tblProject as p on d.depNum=p.depNum
where d.depName = N'Phòng phần mềm nước ngoài'

-- Question 2 (1.5 mark):
-- Indicate working projects in 'TP Đà Nẵng'
-- Required information: project code, project name, and department name responsible for the project
select	p.proNum as N'Project Code',
		p.proName as N'Project Name',
		d.depName as N'Department Name Responsible For The Project'
from tblProject as p
inner join tblLocation as l on p.locNum = l.locNum
inner join tblDepartment as d on p.depNum = d.depNum
where l.locName = N'TP Đà Nẵng'

-- Question 3 (1 mark):
-- Indicate the total number of project hours for each project
-- Required information: project code, project name, total hours
select	p.proNum as N'Project Code',
		p.proName as N'Project Name',
		SUM(w.workHours) as N'Total Hours'
from tblProject as p
inner join tblWorksOn as w on p.proNum = w.proNum
group by p.proNum, p.proName

-- Question 4 (1.5 mark):
-- Indicate the total number of project hours of each department
-- Required information: department code, department name, total hours
select	d.depNum as N'Department Code',
		d.depName as N'Department Name',
		SUM(w.workHours) as N'Total Hours'
from	tblProject as p
inner join tblWorksOn as w on p.proNum=w.proNum
inner join tblDepartment as d on p.depNum=d.depNum
group by d.depNum, d.depName

-- Question 5 (1.5 mark):
-- Indicate the number of departments working in each workplace
-- Required information: name of workplace, number of departments
select	l.locName as N'Name Of Workplace',
		COUNT(p.depNum) as N'Number Of Departments'
from tblProject as p
inner join tblLocation as l on p.locNum = l.locNum
group by l.locName

-- Question 6 (1.5 mark):
-- Which location has the most departments?
-- Required information: name of workplace, number of departments
select 	l.locName as N'Name Of Workplace',
		COUNT(dl.depNum) N'Number Of Departments'
from tblDepLocation as dl
left join tblLocation as l on dl.locNum = l.locNum
group by l.locName
having COUNT(dl.depNum) = (	select MAX(NumberOfWorkplaces)
							from (	select	COUNT(dl2.locNum) as NumberOfWorkplaces
									from tblDepLocation as dl2
									group by dl2.locNum) 
							as MaxDepartments)

-- Question 7 (2 mark):
-- Let's write a program to print a list of employees in a department
-- In each run, the input data is the department code
create procedure Proce_employee
	@departmentcode varchar(10)	
	
as
begin
    select e.*
	from tblEmployee as e
	inner join tblDepartment as d on e.depNum = d.depNum
	where d.depNum = @departmentcode
end;

-- Example: departmentcode is 1
declare @departmentcode varchar(10)
set @departmentcode = '1'
exec Proce_employee @departmentcode

-- Example: departmentcode is 2
declare @departmentcode varchar(10)
set @departmentcode = '2'
exec Proce_employee @departmentcode

-- Example: departmentcode is 3
declare @departmentcode varchar(10)
set @departmentcode = '3'
exec Proce_employee @departmentcode

-- Example: departmentcode is 4
declare @departmentcode varchar(10)
set @departmentcode = '4'
exec Proce_employee @departmentcode

-- Example: departmentcode is 5
declare @departmentcode varchar(10)
set @departmentcode = '5'
exec Proce_employee @departmentcode