use CompanyDB

declare @model_salary as int;
set @model_salary = 90000;
select empSSN, empName, empName, empSalary
from tblEmployee
where empSalary < @model_salary
order by empSSN

